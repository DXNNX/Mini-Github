cd
cd Desktop
mongorestore ./mongo