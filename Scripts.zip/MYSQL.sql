CREATE DATABASE  IF NOT EXISTS `github` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `github`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: github
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comentario`
--

DROP TABLE IF EXISTS `comentario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comentario` (
  `owner` varchar(16) DEFAULT NULL,
  `usuario` varchar(16) NOT NULL,
  `proyecto` varchar(16) NOT NULL,
  `doc` varchar(256) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `comentario` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`usuario`,`proyecto`,`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentario`
--

LOCK TABLES `comentario` WRITE;
/*!40000 ALTER TABLE `comentario` DISABLE KEYS */;
INSERT INTO `comentario` VALUES ('luis','luis','Linked List',NULL,'2018-04-14 10:57:18','Pronto borrarÃ© este proyecto'),('luis','luis','Linked List','node.py','2018-04-14 10:58:13','Pero funciona, asÃ­ que no se quejÃ©'),('luis','luis','Linked List','node.py','2018-04-14 11:03:44','Tranquilo, no pasa nada Pa'),('luis','programador','Linked List','node.py','2018-04-14 10:55:50','Es funcional, pero no lo veo eficiente'),('luis','programador','Linked List','node.py','2018-04-14 11:01:28','Disculpe por el comentario'),('luis','programador','Linked List',NULL,'2018-04-14 11:04:22','No lo borres, sirve mucho para estudiar el cÃ³digo');
/*!40000 ALTER TABLE `comentario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto` (
  `nombreProyecto` varchar(16) NOT NULL,
  `user` varchar(16) NOT NULL,
  `tipo` int(11) DEFAULT NULL,
  `tags` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`user`,`nombreProyecto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto`
--

LOCK TABLES `proyecto` WRITE;
/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` VALUES ('Leones','celina',1,'leona,leon, animales, leones, felino'),('Memes','celina',0,'meme, animal,buho,humor,simpson,ojo'),('Carros','danny',0,'carro,motor,vehiculo,rueda,velocidad,auto'),('Muchos Gatos','danny',0,'gato,felino,animal,fauna,naturaleza,gata'),('Ojos','doctor',0,'ojos, medicina,texto,imagenes,mutilacion'),('Ojos Azules','doctor',0,'Ojos,ojo,azul,medicina,texto,empty project'),('Motos','erick',0,'moto,motor,vehiculo,rueda,velocidad,moticicleta,bici'),('Calendarios','luis',0,'programacion,lua,java,ruby,rb,python,py,computacion'),('Linked List','luis',0,'programacion,java,python,py,computacion,js,json,javascript'),('Ojos','luis',1,'ojos, medicina,texto');
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `usuario` varchar(16) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES ('celina','Celina Vargas','celina@hotmail.com','¸\'Ö›üâú%udÙWë$'),('danny','Danny Chaves Chaves','danny@fake.com','±	!]Òß&=ÐÄêyysE'),('doctor','Doctor Herrera','doctor@fake.com','‚ŸeuM)ÍÔåçðlš™'),('erick','Erick Hernandez','erick@fake.com','â¦\ZyØ¢iAüÙLfím'),('luis','Luis Cascante','luis@fake.com','´iBÕf LÉö\"eeÑ½'),('programador','Programador BD','programador@fake.com',']ÈaÚ\n¯¾;©.m \r');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'github'
--

--
-- Dumping routines for database 'github'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-14 11:09:58
